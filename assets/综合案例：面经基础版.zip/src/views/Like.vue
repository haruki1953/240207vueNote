<template>
  <div>Like</div>
</template>

<script>
export default {
  name: 'LikePage'
}
</script>
