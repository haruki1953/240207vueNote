<template>
  <div>Collect</div>
</template>

<script>
export default {
  name: 'CollectPage'
}
</script>
